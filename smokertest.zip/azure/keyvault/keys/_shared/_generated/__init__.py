# ------------------------------------
# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
# ------------------------------------
from .key_vault_client import KeyVaultClient

__all__ = ["KeyVaultClient"]
